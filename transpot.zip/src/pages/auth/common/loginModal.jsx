const loginModel = {
  login_user_id: "",
  password: "",
  ip: "",
};

export default loginModel;

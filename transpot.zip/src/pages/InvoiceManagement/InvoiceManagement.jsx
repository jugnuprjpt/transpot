import React from "react";
import InvoiceTabbar from "./InvoiceTabbar";

function InvoiceManagement() {
  return (
    <div>
      <InvoiceTabbar />
    </div>
  );
}

export default InvoiceManagement;
